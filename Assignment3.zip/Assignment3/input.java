// Java program to illustrate the 
// concept of Multilevel inheritance 
import java.util.*; 
import java.lang.*; 
import java.io.*; 

class one 
{ 
	public void print_geek() 
	{ 
		System.out.println("Geeks"); 
	} 
} 

class two extends one 
{ 
	public void print_for()	{ 
		System.out.println("for"); 
	} 
} 

public class three extends two { three(){;} 
	three(int sd,int sa){;}
	public void print_geek(two jk) 
	{ 
		System.out.println("Geegeeks// fsdfsdfnsdkgsks"); 
	} 
} 

// Derived class 
public class Main 
{ 
	public static void main(String[] args) 	{ three g = new three(); 
		g.print_geek();
		g.print_for(); 
		g.print_geek(); 
	}
	three ob1;
	two ob1,ob2=ob1;
	two<Integer,Double> obj3;
	
		
	three kl, dfsdf, fdsfas;  
	int three;
	print_for()
	;
} 
